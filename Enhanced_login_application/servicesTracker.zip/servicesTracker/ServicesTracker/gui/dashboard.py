"""
dashboard.py

Programmer: Joshua Battaglia
Date Created: 25SEP2024
Last Modified: 06OCT2024
Version: 0

Description:
This module will contain functions generating the application dashboard window. This file is saved for future enhancement.

Dependencies:
- tkinter
"""